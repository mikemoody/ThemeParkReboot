﻿// Default code generation is disabled for model 'C:\Users\Moody\Dropbox\Docs\MSCS\2016 Summer\Enterprise WebApp Dev 6176\Final Project\ThemePark\ThemePark\App_Code\ReviewModel.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.